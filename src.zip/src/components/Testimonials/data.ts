import { photo, rating } from "@/assets/Testimonials";

export const data = [
  {
    id: 1,
    testimony:
      "I used Surepay to buy something online and it was really safe and made me feel happy. They held onto my money until the seller sent the thing I bought, so I didnt worry. The support team were also really nice and helped me a lot.",
    name: "Mustapha James",
    photo: photo,
    role: "CEO",
    review: rating,
  },
  {
    id: 2,
    testimony:
      "I used Surepay to buy something online and it was really safe and made me feel happy. They held onto my money until the seller sent the thing I bought, so I didnt worry. The support team were also really nice and helped me a lot.",
    name: "Mustapha James",
    photo: photo,
    role: "CEO",
    review: rating,
  },
  {
    id: 3,
    testimony:
      "I used Surepay to buy something online and it was really safe and made me feel happy. They held onto my money until the seller sent the thing I bought, so I didnt worry. The support team were also really nice and helped me a lot.",
    name: "Mustapha James",
    photo: photo,
    role: "CEO",
    review: rating,
  },
];
