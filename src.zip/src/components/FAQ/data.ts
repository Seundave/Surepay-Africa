const faqData = [
  {
    id: 1,
    question: "How does Surepay Africa's escrow payment system work?",
    answer:
      "Buyers make a payment to Surepay Africa, which holds the funds in escrow until the seller delivers the purchased item or service. Once the buyer confirms successful delivery, Surepay Africa releases the funds to the seller",
  },
  {
    id: 2,
    question: "How do I create an account with Surepay Africa?",
    answer:
      "Buyers make a payment to Surepay Africa, which holds the funds in escrow until the seller delivers the purchased item or service. Once the buyer confirms successful delivery, Surepay Africa releases the funds to the seller",
  },
  {
    id: 3,
    question: "What fees are associated with using Surepay Africa?",
    answer:
      "Buyers make a payment to Surepay Africa, which holds the funds in escrow until the seller delivers the purchased item or service. Once the buyer confirms successful delivery, Surepay Africa releases the funds to the seller",
  },

  {
    id: 4,
    question: "How does Surepay Africa handle disputes?",
    answer:
      "Buyers make a payment to Surepay Africa, which holds the funds in escrow until the seller delivers the purchased item or service. Once the buyer confirms successful delivery, Surepay Africa releases the funds to the seller",
  },

  {
    id: 5,
    question: "How does Surepay Africa's escrow payment system work?",
    answer:
      "Buyers make a payment to Surepay Africa, which holds the funds in escrow until the seller delivers the purchased item or service. Once the buyer confirms successful delivery, Surepay Africa releases the funds to the seller",
  },
  {
    id: 6,
    question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit?",
    answer:
      "Buyers make a payment to Surepay Africa, which holds the funds in escrow until the seller delivers the purchased item or service. Once the buyer confirms successful delivery, Surepay Africa releases the funds to the seller",
  },
  {
    id: 7,
    question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit?",
    answer:
      "Buyers make a payment to Surepay Africa, which holds the funds in escrow until the seller delivers the purchased item or service. Once the buyer confirms successful delivery, Surepay Africa releases the funds to the seller",
  },

  {
    id: 8,
    question: "How do I create an account with Surepay Africa?",
    answer:
      "Buyers make a payment to Surepay Africa, which holds the funds in escrow until the seller delivers the purchased item or service. Once the buyer confirms successful delivery, Surepay Africa releases the funds to the seller",
  },
];

export default faqData;
