export const data = [
    {
        id:1,
        image:'',
        step:'Step 1: Sign Up'
    }
]