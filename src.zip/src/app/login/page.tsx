"use client";
import { anotherLogo, logo } from "@/assets/Navbar";
import InputField from "@/reusuables/inputField";
import Image from "next/image";
import Link from "next/link";

function Login() {
  return (
    <div className="max-w-[500px] mx-auto px-[30px]  py-[90px] h-auto  justify-center items-center flex flex-col border-[1px] shadow-md border-gray-300 rounded">
      <form className="w-full flex flex-col gap-3 ">
        <div className="flex flex-col items-center">
          <Image src={logo} alt="another-logo" className=" mb-[20px]" />
        </div>

        <p className="text-center text-[20px] font-bold">
          Sign Up into Surepay
        </p>
        <InputField
          label={"Email Address"}
          type="email"
          autocomplete="email"
          required={{ value: true, message: "Email is required" }}
          placeholder={"goldfish@gmail.com"}
          //   register={{ ...register("email") }}
          //   error={errors?.email?.message}
        />
        <InputField
          label={"Password"}
          type="password"
          autocomplete="password"
          required={{ value: true, message: "Email is required" }}
          placeholder={"Enter your password"}
          //   register={{ ...register("email") }}
          //   error={errors?.email?.message}
        />
        <InputField
          label={"Confirm password"}
          type="password"
          autocomplete="password"
          required={{ value: true, message: "Email is required" }}
          placeholder={"Confirm your password"}
          //   register={{ ...register("email") }}
          //   error={errors?.email?.message}
        />
        <div className="w-full">
          <button className="text-center bg-[#3734A9] rounded text-white w-full md:h-[40px] mt-[20px]">
            Sign in
          </button>
        </div>
      </form>
      <p className="text-[10px] text-center mt-[25px] md:mt-[30px] md:text-[16px]">
        Don’t have an account?{" "}
        <Link href="/sign-up" className="underline text-blue-600">
          Sign Up
        </Link>
      </p>
    </div>
  );
}

export default Login;
