export { default as google } from "./google_logo 1.png";
export { default as shopify } from "./shopify_logo 1.png";
export { default as slack } from "./slack_logo 1.png";
export { default as spotify } from "./spotify_logo 1.png";
export { default as monday } from "./monday_logo 1.png";
export { default as discord } from "./discord_ogo 1.png";
