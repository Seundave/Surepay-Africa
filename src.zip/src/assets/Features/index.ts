export { default as featuresLogo } from "./Commitment.png";
