export {default as twitter} from './Social icon.png'
export {default as github} from './Social icon (3).png'
export {default as facebook} from './Social icon (2).png'
export {default as linkedin} from './Social icon (1).png'