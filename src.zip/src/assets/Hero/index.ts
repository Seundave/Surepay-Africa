export {default as firstImage} from './Illustaration.png';
export {default as secondImage} from './Illustration.png';