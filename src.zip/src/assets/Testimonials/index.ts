export { default as photo } from "./Avatar.png";
export { default as rating } from "./Rating.png";
export { default as quote } from "./Mask group.png";
