export { default as logo } from "./Logo.png";
export { default as anotherLogo } from "./footer-logo.png";